(function () { 
    if (!mstrmojo.plugins.MapTimeLine) {
        mstrmojo.plugins.MapTimeLine = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.CustomVisDropZones",
        "mstrmojo.array"
    );

    mstrmojo.plugins.MapTimeLine.MapTimeLineDropZones = mstrmojo.declare(
        mstrmojo.vi.models.CustomVisDropZones,
        null,
        {
            scriptClass: "mstrmojo.plugins.MapTimeLine.MapTimeLineDropZones",
            cssClass: "offlinemapdropzones",
            getCustomDropZones: function getCustomDropZones(){
  return [ 
 { 
name: "Country", 
title:mstrmojo.desc(13828, 'Drag attributes here'), 
allowObjectType:1, 
maxCapacity: 1,
 }, { 
name:"Time", 
title:mstrmojo.desc(13828, 'Drag attributes here'), 
maxCapacity: 1,
allowObjectType:1
 }, { 
name: mstrmojo.desc(517, 'Metric'), 
title: mstrmojo.desc(13827, 'Drag metric here'), 
allowObjectType:2
 }
 ];},
            shouldAllowObjectsInDropZone: function shouldAllowObjectsInDropZone(zone, dragObjects, idx, edge, context) {
 
 








},
            getActionsForObjectsDropped: function getActionsForObjectsDropped(zone, droppedObjects, idx, replaceObject, extras) {
 
 








},
            getActionsForObjectsRemoved: function getActionsForObjectsRemoved(zone, objects) { 
  
 








},
            getDropZoneContextMenuItems: function getDropZoneContextMenuItems(cfg, zone, object, el) {
 
 








}
})}());
//@ sourceURL=MapTimeLineDropZones.js