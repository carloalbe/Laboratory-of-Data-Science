(function () { 
    if (!mstrmojo.plugins.MapTimeLine) {
        mstrmojo.plugins.MapTimeLine = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.editors.CustomVisEditorModel",
        "mstrmojo.plugins.MapTimeLine.MapTimeLine" ,         
        "mstrmojo.array"
    );
    var $WT = mstrmojo.vi.models.editors.CustomVisEditorModel.WIDGET_TYPE ; 
    mstrmojo.plugins.MapTimeLine.MapTimeLineEditorModel = mstrmojo.declare(
        mstrmojo.vi.models.editors.CustomVisEditorModel,
        null,
        {
            scriptClass: "mstrmojo.plugins.MapTimeLine.MapTimeLineEditorModel",
            cssClass: "offlinemapeditormodel",
            getCustomProperty: function getCustomProperty(){

                  return [
                {
                    name :  mstrmojo.desc("MapTimeLine.1" ,"Configuration").replace(/^\[+|\]+$/g , "")  , 
                    value : [
                        {
                            style: $WT.EDITORGROUP,
                            items: [
                             
                            {
                            style: $WT.TWOCOLUMN,
                            items: [{
                                style: $WT.LABEL,
                                name: "text", 
                                width: "35%",
                                labelText:  mstrmojo.desc("MapTimeLine.2" ,"Color").replace(/^\[+|\]+$/g , "")  
                                }, {
                                    style: $WT.FILLGROUP,
                                    width: "65%",
                                    propertyName: "fillColor",
                                    items: [{
                                        childName: "fillAlpha",
                                        disabled: false 
                                    }]
                                }]
                            } // end of color  
                            , 
                            {
                                style: $WT.TWOCOLUMN,
                                items: [{
                                    style: $WT.LABEL,
                                    name: "text",
                                    width: "25%",
                                    labelText: mstrmojo.desc("MapTimeLine.3" ,"Border").replace(/^\[+|\]+$/g , "")  
                                }, {
                                    style: $WT.LINEGROUP,
                                    width: "75%",
                                    propertyName: "borderColor"
                                }]
                            } // border Color 
                            , 
                            {
                            style: $WT.TWOCOLUMN,
                            items: [{
                                style: $WT.LABEL,
                                name: "text", 
                                width: "35%",
                                labelText: mstrmojo.desc("MapTimeLine.4" ,"Display").replace(/^\[+|\]+$/g , "")  
                                }, {
                                    style: $WT.PULLDOWN,
                                    width: "65%",
                                    propertyName: "displaymode",
                                    items: [
                                        {name : mstrmojo.desc("MapTimeLine.5" ,"Bubble").replace(/^\[+|\]+$/g , "")  ,value:"bubble" } , 
                                        {name : mstrmojo.desc("MapTimeLine.7" ,"Region").replace(/^\[+|\]+$/g , "")  , value : "region"} 
                                    ]   
                                }]
                            } // end of displaymode 
                            ,
                            {
                            style: $WT.TWOCOLUMN, 
                            width : "50%" ,
                                items: [{
                                    style: $WT.LABEL,
                                    name: "text",
                                    width: "70%",
                                    labelText: mstrmojo.desc("MapTimeLine.8" ,"Minimum Size").replace(/^\[+|\]+$/g , "")  
                                }, {
                                    style: $WT.TEXTBOX,
                                    width: "30%",
                                    propertyName: "bubblemin" ,
                                    disabled : this.getHost().getProperty('displaymode') === "region"
                                }]      
                            },
                            {
                            style: $WT.TWOCOLUMN,
                            width : "50%" ,
                                items: [{
                                    style: $WT.LABEL,
                                    name: "text",
                                    width: "70%",
                                    labelText: mstrmojo.desc("MapTimeLine.9" ,"Maximum Size").replace(/^\[+|\]+$/g , "")  
                                }, {
                                    style: $WT.TEXTBOX,
                                    width: "30%",
                                    propertyName: "bubblemax" , 
                                    disabled : this.getHost().getProperty('displaymode') === "region"
                                }]      
                            }
                                ,
                            /* {
                            style: $WT.TWOCOLUMN,
                            width : "50%" ,
                                items: [{
                                    style: $WT.LABEL,
                                    name: "text",
                                    width: "50%",
                                    labelText: mstrmojo.desc("MapTimeLine.10" ,"Select Region").replace(/^\[+|\]+$/g , "")  
                                }, {
                                    style: $WT.PULLDOWN,
                                    width: "50%",
                                    propertyName: "geoJsonFile", 
                                    disabled : this.getHost().getProperty('displaymode') !== "region" , 
                                    items: [
                                        {name : mstrmojo.desc("MapTimeLine.11" ,"World").replace(/^\[+|\]+$/g , "")  ,value:"countries.geo.json" }, 
                                        {name : mstrmojo.desc("MapTimeLine.12" ,"State").replace(/^\[+|\]+$/g , "")  ,value:"Geo_Sido.json" }  ,
                                        {name : mstrmojo.desc("MapTimeLine.13" ,"City").replace(/^\[+|\]+$/g , "")  ,value:"Geo_Sigungu.json" }  
                                    ]  
                                }]      
                            } , */
                            {
                            style: $WT.TWOCOLUMN,
                            width : "50%" ,
                                items: [{
                                    style: $WT.LABEL,
                                    name: "text",
                                    width: "50%",
                                    labelText: mstrmojo.desc("MapTimeLine.14" ,"Zoom").replace(/^\[+|\]+$/g , "")  
                                }, {
                                    style: $WT.PULLDOWN,
                                    width: "50%",
                                    propertyName: "fitRegion", 
                                    // disabled : this.getHost().getProperty('displaymode') !== "region" , 
                                    items: [
                                        {name : mstrmojo.desc("MapTimeLine.15" ,"Static").replace(/^\[+|\]+$/g , "")  ,value:"All" }, 
                                        {name : mstrmojo.desc("MapTimeLine.16" ,"Dynamic").replace(/^\[+|\]+$/g , "")  ,value:"Data" }  
                                    ]  
                                }]      
                            } , 
                            {
	                            style: $WT.CHECKBOXANDLABEL,
	                            propertyName: 'autoplay',
	                            labelText: "Auto Play"   
	                        } , 
                            {
                                style: $WT.TWOCOLUMN,
                                width : "50%" ,
                                    items: [{
                                        style: $WT.LABEL,
                                        name: "text",
                                        width: "50%",
                                        labelText:  "Update Speed"
                                    }, {
                                        style: $WT.PULLDOWN,
                                        width: "50%",
                                        propertyName: "updatespeed", 
                                        // disabled : this.getHost().getProperty('displaymode') !== "region" , 
                                        items: [
                                            {name : "Fast" ,value:500 }, 
                                            {name : "Medium" ,value:1000 }, 
                                            {name : "Slow" ,value:2000 }
                                        ]  
                                    }]      
                                } , 
                            {
                                style: $WT.LABEL,
                                name: "text",
                                width: "100%",
                                labelText: "MapBox URL,Token" 
                            }, {
                                style: $WT.TEXTBOX,
                                propertyName: "mapboxurl",
                                value: ""                                
                            } ,
                            {
                                style: $WT.LABEL,
                                name: "text",
                                width: "100%",
                                labelText: "GeoJSON URL" 
                            }, {
                                style: $WT.TEXTBOX,
                                propertyName: "geojsonurl",
                                value: ""                                
                            }                  
                            ]
                    }
                    ,
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            {
                                style: $WT.LABEL,
                                name: "text",
                                width: "100%",
                                labelText: mstrmojo.desc("MapTimeLine.17" ,"Data Lable").replace(/^\[+|\]+$/g , "")  
                            }, 
                            {
                                style: $WT.BUTTONBAR,
                                propertyName: "dataLabel",
                                items: [
                                  {
                                   labelText: mstrmojo.desc("MapTimeLine.18" ,"Lable").replace(/^\[+|\]+$/g , "")  ,
                                   propertyName: "N"
                                  },
                                  {
                                    labelText: mstrmojo.desc("MapTimeLine.19" ,"Value").replace(/^\[+|\]+$/g , "")  ,
                                    propertyName: "V"
                                  }
                                ],
                                multiSelect:true  
                              }, 
                              {
	                            style: $WT.CHECKBOXANDLABEL,
	                            propertyName: 'hideCollision',
	                            labelText: mstrmojo.desc("MapTimeLine.20" ,"Hide Overlap Label").replace(/^\[+|\]+$/g , "")  
	                        }                                                     
                        ]
                }
                ,{ 
                    style: $WT.EDITORGROUP,
                    items: [{
                        style: $WT.LABEL,
                        name: "text",
                        width: "100%",
                        labelText: mstrmojo.desc("MapTimeLine.21" ,"Lable Format").replace(/^\[+|\]+$/g , "")  
                    }, {
                        style: $WT.CHARACTERGROUP,
                        propertyName: 'labelfont',
                        items: [{
                            childName: 'fontSize'
                        }] ,
                         disabled : this.getHost().getProperty('dataLabel') ? (this.getHost().getProperty('dataLabel').N === "false" && this.getHost().getProperty('dataLabel').V === "false") : false 
                       //disabled : (this.getHost().getProperty('dataLabel')) 
                    }]
                }
                    ]
                } // end of configuration 
                  ] ;







}
})}());
//@ sourceURL=MapTimeLineEditorModel.js