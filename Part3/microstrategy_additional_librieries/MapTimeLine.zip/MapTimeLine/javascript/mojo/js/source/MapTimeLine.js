(function () { 
    if (!mstrmojo.plugins.MapTimeLine) {
        mstrmojo.plugins.MapTimeLine = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.CustomVisBase",
        "mstrmojo.models.template.DataInterface",
        "mstrmojo.vi.models.editors.CustomVisEditorModel"
    );

	
	var $VISUTIL = mstrmojo.VisUtility ; 

	var $pluginName = "MapTimeLine"  ; 
	var isApp = window.webkit ? true  : false ; 
	var libPath = ((mstrApp.getPluginsRoot && mstrApp.getPluginsRoot()) || "../plugins/") + $pluginName  ;  
	var d3Path = libPath + "/lib/d3.v4.min.js" ;  
	var leafletPath = libPath + "/javascript/mojo/js/source/leaflet.js" ;   
	
	function isTrue(value) {
			return value === 'true' || value === true ? true : false;
	}; 

    mstrmojo.plugins.MapTimeLine.MapTimeLine = mstrmojo.declare(
        mstrmojo.CustomVisBase,
        null,
        {
            scriptClass: "mstrmojo.plugins.MapTimeLine.MapTimeLine",
            cssClass: "MapTimeLine",
            errorMessage: "Either there is not enough data to display the visualization or the visualization configuration is incomplete.",
            errorDetails: "This visualization requires one or more attributes and one metric.",
            externalLibraries: [
				{url:(mstrApp.getPluginsRoot && mstrApp.getPluginsRoot() || '../plugins/') +  'MapTimeLine/javascript/mojo/js/source/leaflet.js' },  
				{url:"//d3js.org/d3.v5.min.js"}, 
				{url:(mstrApp.getPluginsRoot && mstrApp.getPluginsRoot() || '../plugins/') +  'MapTimeLine/javascript/mojo/js/source/worldjson.js'},  
				],
            useRichTooltip: true,
            supportNEE: true,
			reuseDOMNode: false, 

			getFontStyle: function getFontStyle(styleName) {
				var fontStyle = {}; 
				var fontProps = this.getProperty(styleName) ;
				fontStyle.fontFamily = fontProps.fontFamily;
				fontStyle.fontColor = fontProps.fontColor ; 
				fontStyle.fontSize = fontProps.fontSize ; 
                fontStyle.fontStyle = isTrue(fontProps.fontItalic) ? 'italic' : 'normal';
                fontStyle.fontWeight = isTrue(fontProps.fontWeight) ? 'bold' : 'normal';
                fontStyle.textDecoration = "";
                if (isTrue(fontProps.fontUnderline)) {
                    fontStyle.textDecoration += ' underline';
                }

                if (isTrue(fontProps.fontLineThrough)) {
                    fontStyle.textDecoration += ' line-through';
                }

                if (fontStyle.textDecoration === "") {
                    fontStyle.textDecoration = "none";
                }                
				return fontStyle ; 
			} , 

            plot:function(){

            // this.addUseAsFilterMenuItem();
            this.addThresholdMenuItem();  // Threshold 
            var DIModel =  new mstrmojo.models.template.DataInterface(this.model.data) ; 
			var rawData , treeData; 
			var data= [];   
			var bMin = 5 , bMax = 30 ; 
			var centerLatLng = [0 , 0] ;
			var lineType = mstrmojo.vi.models.editors.CustomVisEditorModel.ENUM_LINE_STYLE ; 	
			this.setDefaultPropertyValues (  
			 {	 
                fillColor : {fillColor:"#1F77B4" , fillAlpha : 65} , 
                displaymode : "region"  ,
                bubblemin : 10 , 
                bubblemax : 100 , 
               //  geoJsonFile : "Geo_Sido.json" , 
				fitRegion : "All" , 
				updatespeed : 1000 , 
				labelfont: { fontSize: '10pt', fontFamily: 'Open Sans',  fontWeight : 'false' ,  fontColor: '#fff' }   ,
				dataLabel : {N:'true', V:'true' }  , 
				hideCollision : 'true' , 
				autoplay : 'true' , 
				zoomLevel : 3  , 
				centerPosition : {lat : centerLatLng[0] , lng : centerLatLng[1]}  , 
				borderColor : {lineColor: "#ddd" , lineStyle : lineType.THIN }  , 
				mapurl : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' , 
				geojsonurl : libPath + "/javascript/mojo/js/source/world.json" 
			 });

            var fillColor = this.getProperty("fillColor") ;//fillColor , fillAlpha  
            var displaymode =this.getProperty("displaymode") ; 
            var bubblemin    =this.getProperty("bubblemin") ;  
            var bubblemax   =this.getProperty("bubblemax") ; 
          //   var geoJsonFile = this.getProperty("geoJsonFile") ;  
			var fitRegion = this.getProperty("fitRegion") ; 
			var dataLabel = this.getProperty("dataLabel") ; 
			var fontLabel = this.getFontStyle("labelfont");  
			var zoomLevel = this.getProperty("zoomLevel") ;
			var hideCollision = isTrue (this.getProperty("hideCollision")) ; 
			var centerPosition = this.getProperty("centerPosition") ; 
			var borderColor =  this.getProperty("borderColor").lineColor ; 
			var borderStyle = {} ; 
			var autoplay = isTrue (this.getProperty("autoplay")) ; 
			var updatespeed = parseInt(this.getProperty("updatespeed")); 
			switch (this.getProperty("borderColor").lineStyle) {
				case lineType.NONE : 				
					borderStyle = {width : 0 ,dasharray  : 0  };  break ;				
				case lineType.THIN : 
					borderStyle = {width : 1 ,dasharray  : 0  };  break ;				
				case lineType.DASHED : 
					borderStyle = {width : 1 ,dasharray  : 3  };  break ;				
				case lineType.DOTTED : 
					borderStyle = {width : 1 ,dasharray  : 1  };  break ;				
				case lineType.THICK : 
					borderStyle = {width : 2 ,dasharray  : 0  };  break ;				
			}
			if ( fitRegion !== "Data" ) {
				centerLatLng = [centerPosition.lat , centerPosition.lng] ;
			}
			var mapurl = this.getProperty("mapurl");
			var geojsonurl = this.getProperty("geojsonurl") ;
			// 버블 최소 최대 사이즈 프로퍼티 지정 

			Number.isInteger = Number.isInteger || function(value) {
				return typeof value === "number" &&
					   isFinite(value) &&
					   Math.floor(value) === value;
			};
		
			bMin =   Number.isInteger(parseInt(bubblemin)) ? parseInt(bubblemin) : bMin ; 
			bMax =   Number.isInteger(parseInt(bubblemax)) ? parseInt(bubblemax) : bMax ;  
			if (displaymode !== "bubble") { 
				bMin = 10 ;  bMax = 10  ;
			} 
    	    var me = this ; 
            var divWidth = parseInt(me.width) , divHeight = parseInt( me.height) ; 
            var marginWidth = 12 , marginHeight = 12 ; 
            var svgWidth = me.width -marginWidth , svgHeight = me.height -marginHeight; 
        	var svgId = "svg" + this.k ; 
			var divId = "div" + this.k ; 
            rawData =   this.dataInterface.getRawData(mstrmojo.models.template.DataInterface.ENUM_RAW_DATA_FORMAT.ROWS_ADV,
                                    { hasTitleName: true  , hasSelection:true , hasThreshold: true}); 
            var headerCnt = rawData[0].headers.length  ; 
            var metricCnt = rawData[0].values.length  ; 


			// Get Lat and Long attribute 
			//var nameAttribute = this.zonesModel &&  this.zonesModel && this.zonesModel.getDropZoneObjectsByName("Country") ;
			//var timeAttribute = this.zonesModel &&  this.zonesModel && this.zonesModel.getDropZoneObjectsByName("Time")   ;
			var nameAttribute  = DIModel.getRowTitles().getTitle(0).title.id ;
			var timeAttribute =  DIModel.getRowTitles().getTitle(1).title.id ;
			var nameAttributeFormsCnt  = DIModel.getRowTitles().getTitle(0).getForms().length  
				, timeAttributeFormsCnt =DIModel.getRowTitles().getTitle(1).getForms().length  
				, timeAttributeIndex = -1 ;
			// finding attribute index of header and header Information   
			nameAttributeFormsCnt = DIModel.getRowTitles().getTitle(0).getForms().length  ; 
			if (timeAttribute && timeAttribute.length )  {
				timeAttributeFormsCnt = DIModel.getRowTitles().getTitle(1).getForms().length  ; 
				timeAttributeIndex = nameAttributeFormsCnt ; 
			}
			var idTimeData = DIModel.getRowTitles().getTitle(1).title.es ; // for sort..  
			for (j=0 ; j<rawData.length ; j++) 
            {		var c = rawData[j] ;
					var dHeaders = c.headers , dMetrics = c.values ;
					var tmpData = {} ; 
					// process Header Data . 
 
					tmpData.node = [] ;
					for (i=0 ; i<headerCnt  ; i++)
					{
						tmpData.node.push ({nodeName:dHeaders[i].tname , nodeValue:dHeaders[i].name , attributeSelector : dHeaders[i].attributeSelector}) ;					
					}				
					tmpData.name = dHeaders[0].name ; 
					if (nameAttributeFormsCnt > 1){tmpData.lat =  dHeaders[1].name ; }
					if (nameAttributeFormsCnt > 2){tmpData.long = dHeaders[2].name ; }
					tmpData.time = dHeaders[timeAttributeIndex].name ; 				
					tmpData.colorInfo = c.colorInfo;
					// Process Metric Data 
					tmpData.metric = dMetrics[0].rv  ;  
					tmpData.metrics= [] ; 
					for (i=0 ; i<metricCnt ; i++)
					{
						tmpData.metrics.push ({metricName:dMetrics[i].name , metricValue:dMetrics[i].v , metricRValue:dMetrics[i].rv , 
							metricColor : (dMetrics[i].threshold) ? dMetrics[i].threshold.fillColor : undefined }) ;
					}
					for (i=0 ; i<metricCnt ; i++)
					{		
						if (dMetrics[i].threshold) {
							tmpData.metricColor =  dMetrics[i].threshold ? dMetrics[i].threshold.fillColor : undefined  ;
							continue ; 
						}
					}
					if (!tmpData.metricColor) {
						tmpData.metricColor = fillColor.fillColor; 
					}
 

					data.push (tmpData) ;
				};
				
            var selectedItem =""; 
            var ValueExtent = d3.extent( rawData.map( function(d) {  return d.values[0].rv} ) ) ; 
            var radius = d3.scaleLinear().domain(ValueExtent).range([bMin,bMax]);
			var labelData = [] ;  
			var domNode = d3.select(this.domNode); 
			d3.select(this.domNode).selectAll('div').remove();  
			var container  = d3.select(this.domNode).select("div");  
 
			if (container.empty()) {
                container = d3.select (this.domNode).append("div").attr("id","div"+this.k) ; 
				container.style("width", divWidth +"px" ).style("height",(divHeight ) +"px" ).style("position" , "relative")
				.attr("class" , "leaflet-container leaflet-touch leaflet-fade-anim leaflet-grab leaflet-touch-drag leaflet-touch-zoom"); 
				container.append("div").attr("class", "leaflet-bottom leaflet-left"); 
			 }	

			var mymap = L.map(divId, {
				attributionControl : false  
			}).setView(centerLatLng, zoomLevel);  			 
			var tileLayer = L.tileLayer(
			 				 mapurl , 
				{
				maxZoom: 5, minZoom:2,zoomDelta : 0.2 , zoomSnap : 0.1 , 
				attribution: 'Map data &copy; MapBox, ' , 				
				updateWhenIdle : false ,  
				opacity : 1 , 
				id: 'MapBox'
			}).addTo(mymap) ;

			var svgOverlay = L.svg({clickable:true}).addTo(mymap);	
			
 
			timeData = [] ;
			idTimeData.forEach(function(e){
				timeData.push(e.n) ; 
			})  
			var timeFirst = timeData[0] , timeLast = timeData[timeData.length -1]  , timeIndex = 0 ; 
			var time = timeFirst ;
			var sliceData = []; 
			function sliceDataByTime(atime) {
				return data.filter (function(d,i){
					return d.time == atime  && d.metric > 0 ; 
				})
			} 
			sliceData = sliceDataByTime(timeFirst) ; 


			// D3 SVG 
			var d3svg = d3.select (mymap.getPanes().overlayPane).select('svg').attr("pointer-events", "auto") ; 
			var d3g = d3svg.append("g").attr("class","leaflet-zoom-hide") ; 


			var sliderPaneMargin = {left : 0 , top : 0 , height : 40 , padding : 5 } ; 

			// Control SVG  
			var sliderWidth = (divWidth -sliderPaneMargin.left) ; 
			var sliderLabelWidth = 80 , sliderLabelPadding = 85 ;
			var sliderLineWidth = sliderWidth - sliderLabelWidth  * 2  - sliderLabelPadding  -20 ;  
			var buttonWidth = 85 ; 
			var sliderDiv = domNode.append("div").attr("class","sliderDiv")
							.style("top" , (divHeight - sliderPaneMargin.height - sliderPaneMargin.top) + "px")
							.style("left" ,sliderPaneMargin.left+"px")
							.style("width",(divWidth -sliderPaneMargin.left)+"px" )
							.style("height",sliderPaneMargin.height + "px")
							.style("border" ,"solid 1px #ccc");
			var playButton = sliderDiv.append("div").attr("class","raceButton").style("position","absolute")
							.style("top", "10px").style("left","10px") ;

			var prevButton = sliderDiv.append("div").attr("class","raceButton prev").style("position","absolute")
							.style("top", "10px").style("left","35px") ;

			var nextButton = sliderDiv.append("div").attr("class","raceButton next").style("position","absolute")
							.style("top", "10px").style("left","60px") ;
			playButton.classed ("play" , true ) ;
			playButton.on ("click", playMap) ; 
			prevButton.on("click",prevMap);
			nextButton.on("click",nextMap)

			var sliderSvg = sliderDiv.append("svg").attr("width",(divWidth)).attr("height",(sliderPaneMargin.height)).style("overflow","overlay") ;  
			var slider = sliderSvg.append("g").attr("class", "slider")
				.attr("transform", "translate(" + (sliderLabelWidth + sliderLabelPadding) + "," + sliderPaneMargin.height /2  + ")");
			
			sliderDiv.append("div").attr("class" , "sliderLabel").style("width" ,sliderLabelWidth + "px").style("top","0px")
				.style("left",sliderLabelPadding  + "px").style("color" , "#fff").style("height","40px").style("line-height","40px")
				.html(timeFirst) ;
			
			sliderDiv.append("div").attr("class" , "sliderLabel").style("width" ,sliderLabelWidth + "px").style("top","0px")
				.style("left",(sliderWidth - sliderLabelWidth) +"px").style("color" , "#fff").style("height","40px").style("line-height","40px")
				.html(timeLast) ;


			var sliderx = d3.scaleQuantize().domain([0,sliderLineWidth]).range(timeData) ; 
			slider.append("line")
			.attr("class", "track")
			.attr("x1", 0)
			.attr("x2", sliderLineWidth)
		.select(function() { return this.parentNode.appendChild(this.cloneNode(true)); })
			.attr("class", "track-inset")
		.select(function() { return this.parentNode.appendChild(this.cloneNode(true)); })
			.attr("class", "track-overlay")
			.call(d3.drag()
				.on("start.interrupt", function() { slider.interrupt(); })
				.on("start drag", function() {
				currentValue = d3.event.x;
				update(sliderx(currentValue)); 
				})
			);

		var handle = slider.insert("circle", ".track-overlay")
		.attr("class", "handle")
		.attr("cx" ,  0 ) 
		.attr("r", 9);

 
		var label = slider.append("text").attr("class", "label")
		.attr("text-anchor", "middle")
		.text(timeFirst)
		.attr("fill","#fff")
		.attr("x",0)
		.attr("y",0)
		.attr("translate","transform(0,-25)") ;
		label.style("display","none") 
		var handleLabelLeft =(sliderLabelWidth + sliderLabelPadding -40 )  ;
		var handlelabel = sliderDiv.append("div").attr("class" , "handleLabel").style("width" ,sliderLabelWidth + "px").style("top","-20px")
		.style("left", +  handleLabelLeft +"px").style("color" , "#fff").style("height","20px").style("line-height","20px")
		.html(timeFirst) ;
	

		var dataMap  ; 
		dataMap  =  d3.map(sliceData, function (d) { return d.name }) ;  
		var geoJson ;  
		var propertiesNames = ["name", "name_long","iso_a2","iso_a3"  , "admin"] ;
		var geoJsonFeature = [] ;  
		// var duration = 1000 ;
		var duration = updatespeed  ;
		var feature ; 
		var isPlaying = false ; 
		var ticker ; 


			function projectPoint(x, y) {
				var point = mymap.latLngToLayerPoint(new L.LatLng(y, x));
				this.stream.point(point.x, point.y);
			  }
			  
			var transform = d3.geoTransform({point: projectPoint}),
					path = d3.geoPath().projection(transform) ;
			var loadJsonFeature  

			// PDF Export finished event 			
			function renderEvent(msgcall) {
				// console.log("called from " + msgcall + " , and tile is still loading ? " + tileLayer.isLoading() ) ; 
				
				me.raiseEvent({
				name: 'renderFinished',
				id: me.k
					}) ;
				}
			// PDF Export finished 
			tileLayer.on("load", function(){
				renderEvent("tile loaded event");
				}) ;	

			L.DomEvent.on( mymap, "click", function(e){ 
					L.DomEvent.stopPropagation(e);
			});

 
		function getTC (tcData) {
			// get first Threshold color Info. 
				for ( var ti=0 ; ti<tcData.metrics.length ; ti ++ )
				{
					if (tcData.metrics[ti].metricColor && tcData.metrics[ti].metricColor !="" ){
						return tcData.metrics[ti].metricColor ; 
					}
				}
			return fillColor.fillColor  ;
		} ;  

		// Geo Json Map 
	 	drawGeoJsonMap() ; 
		//updateMap () ;  
			 
		mymap.on("moveend",updateMap) ;
		mymap.on("moveend",saveMapProperty) ; 

		if (autoplay) {
			playMap()
		} 

		function  saveMapProperty() {
			try { // Save Map Properties for Center and ZoomLevel ..
				me.setProperty("centerPosition", {lat:mymap.getCenter().lat , lng : mymap.getCenter().lng },{suppressData: true }) ;  
				// [ parseFloat(mymap.getCenter().lat) ,parseFloat(mymap.getCenter().lng)] 
				me.setProperty("zoomLevel",mymap.getZoom(),{suppressData: true}) ;  
				}
			catch (e) {
				console.log("invalid state error") ;
			}
		}

		function updateMap() {
			 addLabelText(labelData, false ) ;
		}

		function drawMarkerMap() {
				// Bubble Map 
				for (i=0 ; i < data.length ; i++ ) {
					var PopupText = "" ; 
					var Mradius =  radius(data[i].metrics[0].metricRValue)   ; 
					var MetricColor = "" 
					MetricColor = getTC(data[i]) ; 
					 
					// 팝업에 표시할 데이터 지정
					for (hi =0 ; hi < data[i].node.length ; hi ++ ) {
							PopupText += "<b>" + data[i].node[hi].nodeName + ": " +data[i].node[hi].nodeValue + "</b><br />" ;  
						}
					for (mi =0 ; mi < data[i].metrics.length ; mi ++ ) {
							PopupText += data[i].metrics[mi].metricName + " : " +  data[i].metrics[mi].metricValue  + "<br />" ;  
						}
					var circleMarker =L.circleMarker([data[i].lat, data[i].lon],  
							{
							radius: Mradius , 
							// color: '#ddd',
							color : borderColor , 
							stroke : true , 
							dashArray :borderStyle.dasharray ,
							weight : borderStyle.width , 
							fillColor:MetricColor ,
							fillOpacity:  parseInt(fillColor.fillAlpha) / 100   , 
							className : "nodecircles"
							}
							).addTo(mymap)
						.bindPopup(PopupText)
						// .bindTooltip(data[i].node[0].nodeValue , {permanent:true  , className : svgId+"label",offset:[0,0],opacity:1 })
						;				   					
				}

				// 마커  선택 이벤트 추가 -> 선택시 다른 시각화 업데이트  
				var nodecircles = container.selectAll(".nodecircles").data(data); 
				nodecircles.on("click", function(d,i){ 
					selectedItem  = d.node[0].attributeSelector; 
					me.applySelection(d.node[0].attributeSelector); //for web
				} );

				// 선택 된것 지우기 이벤트 
				container.on("click" , function(d,i){ 
					// console.log("container click") ;
					// d3.event.stopPropagation(); // ? 
							// if (!event.target.classList.contains('nodecircles')&& selectedItem  !="") {
								if (event.srcElement.classList && !event.srcElement.classList.contains('nodecircles')&& selectedItem  !="") {	// for ie10 
								if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.selectionDataJSONString) {  // mobile
									var d = {}
									d.messageType = "deselection";
									window.webkit.messageHandlers.selectionDataJSONString.postMessage(d);
								} else {
									me.clearSelections();
									me.endSelections();
								}
								selectedItem  = ""; 
							} else {
								return true;
							}
				}); 
				// Center or not .. 
				if ( fitRegion === "Data") {
					var myBounds =	new  L.LatLngBounds (data.map (function(e) { return [+e.lat,+e.lon]})) ; 
					mymap.fitBounds (myBounds,zoomLevel) ;
				}
 				labelData =  data   ; 
		}


		function drawGeoJsonMap() {
				
			 var geoJsonFilePath = geojsonurl; //  libPath + "/javascript/mojo/js/source/world.json" ;  
 				makeGeoLayer(worldgeojson) ;
				function makeGeoLayer (argloadJsonFeature) { 
						loadJsonFeature = argloadJsonFeature ;				
					 	mymap.on("moveend", reset)  ;  	
						mapChartRace (time) ;    
					 	reset() ;
						// ticker = d3.interval (playMap,duration,d3.now()); 
					}  
		}
 
		function prevMap() {
			var prevIndex = timeIndex -1 ; 
			if (prevIndex>=0) {
 			prevTime= timeData[prevIndex] ;
			timeIndex-- ; 
			}
			update(prevTime) ;  
		}

		function nextMap() {
			var nextIndex = timeIndex + 1 ; 
			if (nextIndex <=timeData.length ) {
 			nextTime= timeData[nextIndex] ;
			timeIndex++ ; 
			}
			update(nextTime) ;
		}
		
		function playMap() {
			if (isPlaying) {
				ticker.stop () ;  
				isPlaying = false
				togglePlay(true ) ; 
			} 
			else { 
				runningMap() ; 
				ticker = d3.interval (runningMap,duration,d3.now()); 
				isPlaying = true ; 
				togglePlay(false) ;	
			} 
		}

		function update (h)  {
				var handlex = (h==timeLast)  ?  sliderx.invertExtent(h)[1] : sliderx.invertExtent(h)[0] ; 	
				handle.attr("cx", handlex);
				label.attr("x", handlex).text(h);
				label.text(h);
				handlelabel.style("left", (handleLabelLeft + handlex)+"px");
				handlelabel.html(h);
				mapChartRace (h);
			}

		function runningMap () {
			currentTime = timeData[timeIndex] ;
			
			console.log(currentTime) ; 

			update(currentTime) ;  
			timeIndex ++ ; 
			if(currentTime  == timeLast  )  {
				ticker.stop(); 
				togglePlay(true) ;
				time = timeFirst ; 
				timeIndex = 0 ; 
			}  
		}

		function togglePlay(toggle) {
			playButton.classed("play",toggle) ;
			playButton.classed("stop",!toggle ) ;
		}
				
		// reset D3 SVG 

		function reset() {
			if (displaymode=="region") {
			feature.attr("d", path);  
				}
		else {
			feature.attr("cx", function (d) {return  mymap.latLngToLayerPoint(d.data.LatLng).x})
					.attr("cy", function (d) {return  mymap.latLngToLayerPoint(d.data.LatLng).y}) 
				}
		}
		  

		function mapChartRace(currentTime) {
					
			sliceData = sliceDataByTime(currentTime) ; 
			var featureLabel = []  ;
			dataMap  =  d3.map(sliceData, function (d) { return d.name }) ;  
			var dataMapPrevious = dataMap ; 
			// timeIndex = timeData.findIndex(d=>d==currentTime) ; 
			timeIndex = timeData.findIndex(function (d) { return d==currentTime; }) ; 
			ti = timeIndex -1 ; 
			if (ti>=0 ) {
				dataMapPrevious = d3.map(sliceDataByTime(timeData[ti]), function (d) { return d.name }) ;
			}
			sliceData.forEach(function(e){
				if ( dataMapPrevious.get(e.name)){ 
					e.lastValue = dataMapPrevious.get(e.name).metric ;
				}
				else 
				{
					e.lastValue= e.metric ; 
				} 
			})   
			
			var geoJsonFeature = [] ;   
			for (l = 0 ; l <   loadJsonFeature.features.length ; l ++ ) {
				var dataElement  =  findData (loadJsonFeature.features[l]) ;
						if (dataElement) {  
							tmpFeature = loadJsonFeature.features[l] ; 
							tmpFeature.data = dataElement ; 
							geoJsonFeature.push (tmpFeature) ;
							continue ; 
						}
			} 

			geoJsonFeature.forEach(function(d,i){
				var tmp = {} ; 
				tmp.name  = d.data.name ;
				tmp.LatLng = [d.data.lat , d.data.long]  ; 
				if (!d.data.lat) {
					tmp.LatLng = mymap.layerPointToLatLng(path.centroid(d.geometry)) ; 
				}
				d.data.LatLng = tmp.LatLng ; 
				tmp.metric = d.data.metric  ; 
				tmp.lastValue = d.data.lastValue ; 
				featureLabel.push (tmp) ;
			}) 

			if (displaymode == "region") 
			{
				regionMap(); 
			}
			else 
			{
				bubbleMap() ; 
			} 
			function  showToolTip (d) { 
				var tooltipHtml ; 
				// var eventLatLng = mymap.layerPointToLatLng ([d3.event.layerX , d3.event.layerY])  ; 
				// tooltip bind 
				tooltipHtml  = tooltipPopupContents (d ) ;
				svgOverlay.bindTooltip(tooltipHtml , {permanent : false  , sticky:true , direction : "auto" ,  offset : [0,0]})
					 .openTooltip(d.data.LatLng) ;
					// .openTooltip(eventLatLng) ;
					
			} 

			function closeToolTip(){
				svgOverlay.unbindTooltip(); 
			}
			function tooltipPopupContents (d) {  
				var tooltipHtml ;
			 
				var tooltipData = d.data.node  ; 
				var tooltipMetric = d.data.metrics ;  
				// if (tooltipData.length == 0 ) { return }
				var tooltipHtml = "<table class='tooltipTable'>" ;
				tooltipData.forEach(function (datum,index ) {
					tooltipHtml += "<tr><td class='tooltipName'>"+datum.nodeName  +"</td><td class='tooltipValue'>" + datum.nodeValue + "</td></tr>" ;
				})	 
				tooltipMetric.forEach(function (datum,index ) {
					tooltipHtml += "<tr><td class='tooltipName'>"+datum.metricName  +"</td><td class='tooltipValue'>" + datum.metricValue  + "</td></tr>" ;
				})	 
				tooltipHtml += "</table>" ;
				return tooltipHtml ;
			}  
 

			// GeoJSON Map 
			function regionMap() {
	 
				// D3 path 		
				feature = d3g.selectAll("path")
					.data(geoJsonFeature , function (d) { return d.data.name })
					.join (function ( enter) { return   enter.append("path")} , 
					function(update) {return  update} , 
					function (exit) {return  exit.remove()} )  ;

				// feature.enter().append("path");
				feature.attr("d", path).style("fill",parseInt(fillColor.fillAlpha) / 100)
						.attr("stroke",borderColor)
						.attr("stroke-width" ,borderStyle.width )
						.attr("stroke-dasharray",borderStyle.dasharray) ;
				feature.style("pointer-events","auto");
				feature.transition().duration(duration).ease(d3.easeLinear).attr("fill" ,function(d,i) {			 
							return d.data.metricColor  ;
						} ) ;
			} // Draw Region

			function bubbleMap() { 
				// Bubble Map 
				feature = d3g.selectAll("circle")
				.data(geoJsonFeature , function (d) { return d.data.name })
				.join (function ( enter) { return   enter.append("circle")} , 
					function(update) {return  update} , 
					function (exit) {return  exit.remove()}  )  ;
				feature.attr("cx",function (d){ 
					return mymap.latLngToLayerPoint(d.data.LatLng).x 
				})						
				.attr("cy",function (d){ 
					return mymap.latLngToLayerPoint(d.data.LatLng).y 
				})
				.attr("stroke",borderColor)
				.attr("stroke-width" ,borderStyle.width )
				.attr("stroke-dasharray",borderStyle.dasharray)
				.style("fill-opacity", parseInt(fillColor.fillAlpha) / 100 )
				.transition().duration(duration).ease(d3.easeLinear)
						.attr("fill",function(d) {return d.data.metricColor })
						.attr("r",function (d) {return  radius(d.data.metric)}); 

				feature.style("pointer-events","auto");
			} // Draw Bubble 
			labelData = featureLabel ; 
			addLabelText( featureLabel) ;
			
		// 	reset(); 						
		}


				function geoStyle (feature) {
					var mcolor = fillColor.fillColor ; 
					var featureProperty= feature.properties.name  ;
					var dataElement  =  findData (feature) ; 
					if (dataElement) {
						mcolor = getTC( dataElement) ;
					}
					return  { color : borderColor  , "weight" : 0 , "opacity" : 0 ,/* "fillColor" : "transparent" , */ "fillOpacity" : 0   
						, dashArray : borderStyle.dasharray  , weight :  borderStyle.width }  ; 
				}

				function regionClick (e) {
					var layer = e.target; 
					var feature = layer.feature ; 
					if (feature.data.node[0]) {
						if ( selectedItem !== feature.data.node[0].attributeSelector ) {
							selectedItem  = feature.data.node[0].attributeSelector; 
							me.applySelection(selectedItem); //for web
						}
						else {  // Delete Selected Area
							selectedItem = "" ; 
							me.clearSelections();
							me.endSelections();		                		              
						}
					}
				}

				function resetHighlight(e) {
				geoJson.resetStyle(e.target);
				}

				function highlightFeature(e) {
					var layer = e.target;
					layer.setStyle({				        
						fillOpacity:0.8  
					});
				}

				function onEachFeature(feature , layer)  {											
					var dataElement  =  findData (feature) ;
					if (dataElement) {
						feature.data =dataElement;
					}											
					layer.on({mouseup:regionClick , mouseover:highlightFeature , mouseout :  resetHighlight}); 
				}


				function setToolTip (layer) {
					//console.log (layer); 
					var PopupText = "" ; 
					if ( layer.feature.data  ) { 

					// 팝업에 표시할 데이터 지정
					for (hi =0 ; hi < layer.feature.data.node.length ; hi ++ ) {
							PopupText += "<b>" + layer.feature.data.node[hi].nodeName + ": " + layer.feature.data.node[hi].nodeValue + "</b><br />" ;  
						}
					for (mi =0 ; mi < layer.feature.data.metrics.length ; mi ++ ) {
							PopupText += layer.feature.data.metrics[mi].metricName + " : " +  layer.feature.data.metrics[mi].metricValue  + "<br />" ;  
						}
						return PopupText ; //   layer.feature.properties.KOR_NM ; 
					}
					else 
						{return "" } ; 
				}

				function findData (feature) {
					for (i = 0 ; i < propertiesNames.length ; i++) {
						if ( dataMap.get(feature.properties[propertiesNames[i]]) ) 
							return dataMap.get(feature.properties[propertiesNames[i]])  ; 
					}
				} 

	 
		function d3FormatArea() {
			var path = container.selectAll("path") ; 
			path.transition().duration(500).ease(d3.easeLinear).attr("fill" ,function(d,i) {			 
				return d.metrics[0].metricColor  ;
			} ) ;

			// path.transition().duration(500).ease(d3.easeLinear).attr("fill" ,function(d,i) {
		}

		function addLabelText (targetLabelData ,isDataChanged) {
			if (isDataChanged == undefined ) {isDataChanged = true };
 
			// Add d3 Text test 
			// var mapsvg = d3.select ("#" +divId).select("svg") ;				
			
			var valueMargin = parseInt(fontLabel.fontSize) + 4  ; ; 
			var mapG = d3svg.select("#label"+divId ) ;
			if (mapG.empty()) {
				mapG = d3svg.append("g").attr("id","label"+divId ) ; 
			}
			textLabelData = targetLabelData ; 
			// mapG.selectAll("text").remove() ; 
			 
			var labels = mapG.selectAll("text").data(textLabelData, function (d){return d.name ; }) ;
			labels.exit().remove() ; 
			var textLabel =  labels.enter().append("text")
 				.style("font-size", fontLabel.fontSize )
				.style("font-family" , fontLabel.fontFamily) 
				.attr("fill", fontLabel.fontColor)
				.attr("visibility" , "hidden") ;

				textLabel.append("tspan")
				.attr("class","labelName")
				.style("text-anchor","middle")
					.attr("y" , 0 ).attr("x",0)
					.text(function(d) {
						 return 	d.name  ;  
						 }) ;

				textLabel.append("tspan")
				.attr("class","labelValue")
				.style("text-anchor","middle")
					.attr("y" , valueMargin ).attr("x",0)
					 .text(function(d) {
						 return 	 d3.format(',')(d.metric	)  ;  
						 }) ; 

				textLabel = textLabel.merge(labels) ; 

				if (!isTrue(dataLabel.N)){ 
					textLabel.selectAll(".labelName").style("display","none"); 
					textLabel.selectAll(".labelValue").attr("y",parseInt(fontLabel.fontSize) /2 ); 
				} 
				if (!isTrue(dataLabel.V)) {
					textLabel.selectAll(".labelValue").style("display","none"); 
				}


				textLabel.attr("id", function (d,i){
					return "label_" + i ; 
				});

				textLabel.selectAll(".labelValue")
					.datum(function(d) { 
						return d3.select(this.parentNode).datum() ; 
					})
					.transition()
					.duration(duration)
					.ease(d3.easeLinear) 
					.tween("text", function(d) { 
						var lastValue = isDataChanged ?  d.lastValue  : d.metric ; 
						var i = d3.interpolateRound(lastValue , d.metric);
						return function(t) {  
						this.textContent = d3.format(',')(i(t));
						};
					})  

			textLabel.attr ("transform" , function (d) {
				return "translate("  + 
				mymap.latLngToLayerPoint(d.LatLng).x  + "," +(mymap.latLngToLayerPoint(d.LatLng).y )  +")"
			}) ; 

			if (hideCollision) {
				var labelNodes = textLabel.nodes() ;
				var labelLength = labelNodes.length ;

				var labelRect = {} , labelMatrix  = {} , labelDisplayList = {} , labelHideList = {} , labelID , matrixSize  = 10 ; 
				// Create label Rect Matrix 
				for (var l = 0 ; l < labelLength; l ++ ) {
					var o =  labelNodes[l].getBoundingClientRect() ;
					labelID = "label_"  + l ; 
					labelRect[labelID] = o ; 
					// Create Label Matrix 
					CreateLabelMatrix(labelID, o ) ; 
					labelDisplayList[labelID]  = true ; 
				}			

				// Detect Collision
 				for (var l = 0 ; l < labelLength; l ++ ) {
					labelID = "label_"  + l ; 
					var o =  labelRect[labelID] ;
					if (!labelDisplayList.hasOwnProperty(labelID)) {  
						continue  ; 
					}
					var g = cellStartEnd(o) ; 
					for (i=g.rowStart; i<g.rowEnd ; i++ ) {
						for (j =g.colStart ; j< g.colEnd ; j++) {
							if (labelMatrix[i] && labelMatrix[i][j]) {
								coNodes = labelMatrix[i][j] ; 
								for (node in coNodes) {
									if (labelID == node) { continue ; } 
									if (coNodes.hasOwnProperty(node) && labelDisplayList.hasOwnProperty(node) ) { 
										delete labelDisplayList[node] ; 
										labelHideList[node] = true ;   
										//console.log("hide"+node);
										coNodes[node]  = false ; 
									}
								}
							}
						}
					}
				}
				// console.log(labelDisplayList) ;
			

				var Nodeselector = "",  NodeHideselector = "" , NodeHideListLength = 0 ,  NodeselectorLength = 0 ; 
				for (node in labelDisplayList) {
					Nodeselector += (NodeselectorLength == 0 ? "" : "," ) +  "#" + node ;
					NodeselectorLength += 1  ;
				}
				for (node in labelHideList) {
					NodeHideselector += (NodeHideListLength == 0 ? "" : "," ) +  "#" + node ;
					NodeHideListLength++ ; 
				} 
				if ( NodeHideListLength>0 )
					{
						mapG.selectAll(NodeHideselector ).attr("visibility","hidden").attr("class","MapTimeLineLabel");
					} 
				if (NodeselectorLength > 0 ) {
					mapG.selectAll(Nodeselector ).attr("visibility","visible").attr("class","MapTimeLineLabel");
				}

				function CreateLabelMatrix(lableID, o) {
					var g = cellStartEnd(o) ; 
					for (i=g.rowStart; i<g.rowEnd ; i++ ) {
						for (j =g.colStart ; j< g.colEnd ; j++) {
							if (!labelMatrix[i] ){
								labelMatrix[i] = {} ; 
							}
							if (!labelMatrix[i][j]) {
								labelMatrix[i][j] = {} ; 
							}
								labelMatrix[i][j][labelID] = true ; 
						}
					}
				}

				function cellStartEnd (n) {
					var g= {}  ;
					g.rowStart =  Math.floor(n.top / matrixSize  ) ;
					g.rowEnd =  Math.floor(n.bottom  / matrixSize  ) ;
					g.colStart =  Math.floor(n.left  / matrixSize  ) ;
					g.colEnd  =  Math.floor(n.right   / matrixSize  ) ;
					return g ; 
				}
			 }  
			 else {
				textLabel.attr("visibility","visible") ; 
			 } 
 
	} // End of drawLabel .. 

	L.DomEvent.disableClickPropagation ( me.domNode ) ; 

}})}());
//@ sourceURL=MapTimeLine.js

